// Function to change the website theme (light/dark mode)
function toggleTheme() {
  const body = document.body;
  body.classList.toggle('dark-theme');
  // Save theme preference in localStorage
  if (body.classList.contains('dark-theme')) {
    localStorage.setItem('theme', 'dark');
  } else {
    localStorage.setItem('theme', 'light');
  }
}

// Load theme preference from localStorage on page load
window.onload = () => {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
  }
};

// Function to interact with a chess bot (example)
function playBot() {
  alert("Playing against the bot! Let's see who wins.");
  // You can integrate this with a chess API for bot play functionality
}

// Adding event listener for PlayBot button in the navigation bar
document.getElementById('playbot-btn').addEventListener('click', playBot);

// Adding event listener for theme toggle button (if you decide to add one to your website)
document.getElementById('theme-toggle-btn').addEventListener('click', toggleTheme);

// Optional: Adding a countdown or timer functionality (could be used for a live game)
let gameTimer;
let timeLeft = 300; // 5 minutes timer (in seconds)

function startTimer() {
  const timerElement = document.getElementById('timer');
  gameTimer = setInterval(() => {
    if (timeLeft <= 0) {
      clearInterval(gameTimer);
      timerElement.innerHTML = 'Time’s up!';
    } else {
      timeLeft--;
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      timerElement.innerHTML = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    }
  }, 1000);
}

// Call startTimer to initiate timer (You can customize this to start with the game or button click)
startTimer();
